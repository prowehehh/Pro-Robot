const { 
    Client, GatewayIntentBits, Partials, PermissionsBitField, EmbedBuilder, 
    REST, Routes, SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType,
    ModalBuilder, TextInputBuilder, TextInputStyle, AuditLogEvent,
    UserSelectMenuBuilder, ContextMenuCommandBuilder, ApplicationCommandType,
    StringSelectMenuBuilder, PermissionFlagsBits
} = require('discord.js');
const express = require('express');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const app = express();

// ============================================================
// --- ✅ [DATABASE] MongoDB Connection & Schema ---
// ============================================================
const mongoose = require('mongoose');

mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('✅ Pro-Robot Database: Connection Successful'))
    .catch(err => console.error('❌ Pro-Robot Database: Connection Error', err));

const serverSchema = new mongoose.Schema({
    guildId: String,
    cmdPermissions: { type: Map, of: String, default: {} },
    userWarns: { type: Map, of: Number, default: {} }
});

const ServerModel = mongoose.model('ServerData', serverSchema);

async function getDB(guildId) {
    let data = await ServerModel.findOne({ guildId });
    if (!data) {
        data = await ServerModel.create({ guildId });
    }
    return data;
}

const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.send('Pro Robot is Online! 🤖');
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.GuildMessageReactions,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction],
    presence: {
        status: 'online',
        activities: [{
            name: 'Custom Status',
            state: '🤖 | Version: 5.0',
            type: 4
        }]
    }
});

const CONFIG = {
    WELCOME_CH: '1482881348204101768',
    AUTO_ROLE: '1482883802186514615',
    AUTO_ROLE_2: '1499510435639197887',
    OWNER_ID: '1134146616857731173',
    BOT_ID: '1495419259147386920',
    HELP_CH: '1497909981725593712',
    SUBMIT_LOG: '1494367980702797935',
    ROLE_CHANNEL: '1482874761951576228',
    INFO_CH: '1484641160394702958',
    DM_LOG_CH: '1502084414421729340'
};

const adsStorage = new Map();
const warnStorage = new Map();
const dmAdsStorage = new Map();
const dmSettingsStorage = new Map();

// ============================================================
// --- ✅ [SECURITY] Protection Storage ---
// ============================================================
const spamTracker = new Map();       // userId -> { count, timer }
const raidTracker = new Map();       // guildId -> { joins: [], locked }
const SPAM_LIMIT = 5;                // max messages in timeframe
const SPAM_WINDOW = 5000;            // 5 seconds
const RAID_THRESHOLD = 8;            // members joining in short time
const RAID_WINDOW = 10000;           // 10 seconds
const NEW_ACCOUNT_DAYS = 7;          // min account age in days
const MIN_ACCOUNT_MS = NEW_ACCOUNT_DAYS * 24 * 60 * 60 * 1000;

// ============================================================
// --- ✅ [NEW] formSettingsDB — Stores dynamic form configs ---
// ============================================================
const formSettingsDB = new Map();

const pendingUpdates = new Map(); 
const ADMIN_PASSWORD = "Pro@Robot510";
let extraServerInfo = ""; 

// ============================================================
// --- ✅ [NEW] DM Logger - Logs All Bot DM Activity ---
// ============================================================
async function logDMActivity(userId, username, content, type = 'IN_TEXT', extraData = {}) {
    const logCh = client.channels.cache.get(CONFIG.DM_LOG_CH);
    if (!logCh) return;

    let logEmbed;

    if (type === 'IN_TEXT') {
        logEmbed = new EmbedBuilder()
            .setTitle('📥 INCOMING PRIVATE SIGNAL')
            .addFields(
                { name: 'Sender', value: `<@${userId}>`, inline: true },
                { name: 'User ID', value: `${userId}`, inline: true },
                { name: 'Message Content', value: content || '[Empty]', inline: false }
            )
            .setColor('#f1c40f')
            .setTimestamp();

    } else if (type === 'IN_MEDIA') {
        logEmbed = new EmbedBuilder()
            .setTitle('🖼️ PRIVATE MEDIA DETECTED')
            .addFields(
                { name: 'Sender', value: `<@${userId}>`, inline: true },
                { name: 'Status', value: 'Attachment Received', inline: true },
                { name: 'Content', value: '(The image will be displayed below)', inline: false }
            )
            .setColor('#e67e22')
            .setTimestamp();
        if (extraData.imageUrl) logEmbed.setImage(extraData.imageUrl);

    } else if (type === 'AI_RESPONSE') {
        logEmbed = new EmbedBuilder()
            .setTitle('🤖 AI AUTOMATIC RESPONSE')
            .addFields(
                { name: 'Target User', value: `<@${userId}>`, inline: true },
                { name: 'AI Response', value: content || '[Empty]', inline: false }
            )
            .setColor('#3498db')
            .setTimestamp();

    } else if (type === 'ALERT') {
        logEmbed = new EmbedBuilder()
            .setTitle('⚠️ DM SYSTEM ALERT')
            .addFields(
                { name: 'User', value: `<@${userId}>`, inline: true },
                { name: 'Activity', value: content || 'Multiple messages detected.', inline: false }
            )
            .setColor('#e74c3c')
            .setTimestamp();

    } else {
        logEmbed = new EmbedBuilder()
            .setTitle('📤 DM Sent (Bot → User)')
            .addFields(
                { name: 'Target', value: `<@${userId}>`, inline: true },
                { name: 'Content', value: content || '[Empty]', inline: false }
            )
            .setColor('#2ecc71')
            .setTimestamp();
    }

    await logCh.send({ embeds: [logEmbed] }).catch(() => {});
}

// ============================================================
// --- ✅ [NEW] Moderation DM Notifier ---
// ============================================================
async function sendModDM(user, action, reason, guildName) {
    try {
        const dmChannel = await user.createDM();
        const modEmbed = new EmbedBuilder()
            .setTitle(`⚠️ Action Taken — ${guildName}`)
            .setDescription(`You have received a moderation action in **${guildName}**.`)
            .addFields(
                { name: '🔨 Action', value: `**${action}**`, inline: true },
                { name: '📝 Reason', value: reason || 'No reason provided.', inline: true }
            )
            .setColor('#e74c3c')
            .setTimestamp()
            .setFooter({ text: 'Pro Robot Security System • Pro Server' });

        await dmChannel.send({ embeds: [modEmbed] });
        await logDMActivity(user.id, user.tag, `[🔨 MOD NOTIFICATION] Action: ${action} | Reason: ${reason}`, 'OUT');
    } catch (err) {
        console.error(`❌ Failed to send mod DM to ${user.tag}:`, err);
    }
}

// ============================================================
// --- ✅ [1] AI Global Brain — Upgraded to Gemini ---
// ============================================================
const chatMemory = new Map();

async function getEliteAIResponse(userId, userMessage, guild) {
    const memberCount = guild.memberCount;
    const serverName = guild.name;
    const owner = guild.members.cache.get(CONFIG.OWNER_ID)?.user.username || "Saif";

    if (!chatMemory.has(userId)) {
        chatMemory.set(userId, []);
    }
    let memory = chatMemory.get(userId);

    const systemPrompt = `You are "Pro Robot", the all-knowing AI assistant and Executive Manager of the Discord server "${serverName}".

IDENTITY:
- You are not a simple bot. You are a highly advanced AI with deep knowledge across ALL fields: science, technology, history, math, gaming, sports, culture, religion, medicine, law, programming, and more.
- You act as a trusted co-owner of this server alongside ${owner} (<@${CONFIG.OWNER_ID}>).
- Server has ${memberCount} members under your supervision. Location: Egypt.

KNOWLEDGE & ANSWERS:
- You MUST answer EVERY question asked, no matter the topic, with FULL detail, accuracy, and depth.
- NEVER say "I don't know" or refuse to answer general knowledge questions. Always provide a thorough, well-structured response.
- For complex topics, break your answer into clear sections or bullet points.
- Include examples, explanations, and context whenever helpful.
- If a question has multiple parts, answer each part clearly.

LANGUAGES:
- You are a polyglot. Detect the user's language and respond in the EXACT same language.
- If the user writes in Arabic (Egyptian dialect or formal), respond in Arabic.
- If the user writes in English, respond in English.
- Never mix languages unless the user does so first.

MEMORY:
- You remember the full conversation history. Use it to give continuous, connected answers.
- Reference previous messages when relevant to show you're paying attention.

TONE:
- Be professional, friendly, and authoritative.
- For server-related questions, be formal and confident.
- For casual questions, be approachable and engaging.

SPECIAL RULE:
- If the user asks to change, add, or update any server setting or info, respond with: "لمعالجة هذا الطلب، يرجى الضغط على الزر أدناه وإدخال كلمة المرور." (or in English if they asked in English).`;

    memory.push({ role: "user", parts: [{ text: userMessage }] });

    if (memory.length > 20) {
        memory.splice(0, 2);
    }

    try {
        const response = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${process.env.GOOGLE_API_KEY}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    systemInstruction: { parts: [{ text: systemPrompt }] },
                    contents: memory,
                    generationConfig: { temperature: 0.8, maxOutputTokens: 2000 }
                })
            }
        );

        const data = await response.json();
        console.log("Gemini API status:", response.status);
        console.log("Gemini API response:", JSON.stringify(data).slice(0, 500));
        const aiReply = data.candidates?.[0]?.content?.parts?.[0]?.text 
            || `Pro Robot AI is not available! You have to go the owner "<@${CONFIG.OWNER_ID}>"`;

        memory.push({ role: "model", parts: [{ text: aiReply }] });
        chatMemory.set(userId, memory);

        return aiReply;

    } catch (error) {
        console.error("AI System Error:", error);
        return `حدث خطأ في الاتصال بالذكاء الاصطناعي، حاول مرة أخرى! <@${CONFIG.OWNER_ID}>`;
    }
}

function isQuestion(text) {
    const t = text.trim().toLowerCase();
    if (t.includes('?') || t.includes('؟')) return true;
    const questionWords = [
        'كيف','ماذا','لماذا','متى','أين','اين','من','ما ','هل','ايه','ازاي','امتى','فين','مين','ليه','وين','شو','ليش','قديش','كم ',
        'how','what','why','when','where','who','which','whose','whom',
        'can ','could','would','should','is ','are ','was ','were ','does ','do ','did ','will ','shall ','has ','have ','had '
    ];
    return questionWords.some(w => t.startsWith(w) || t.includes(' ' + w.trim() + ' '));
}

async function sendDetailedLog(guild, title, details, color = '#3498db') {
    const logChannel = guild.channels.cache.get(CONFIG.SUBMIT_LOG);
    if (!logChannel) return;

    setTimeout(async () => {
        const fetchedLogs = await guild.fetchAuditLogs({ limit: 1 }).catch(() => null);
        const logEntry = fetchedLogs?.entries.first();
        const executor = logEntry ? `<@${logEntry.executor.id}>` : "System / Unknown";

        const logEmbed = new EmbedBuilder()
            .setTitle(`📡 RADAR: ${title}`)
            .setDescription(details)
            .addFields(
                { name: '👤 Executor:', value: `**${executor}**`, inline: true },
                { name: '📍 Location:', value: guild.name, inline: true }
            )
            .setColor(color)
            .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
    }, 2000);
}

const BAD_WORDS = ['word1', 'word2', 'word3']; 

// ============================================================
// --- ✅ [2] Legendary Anti-Link & Security System ---
// ============================================================
const inviteLinkRegex = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li)|discordapp\.com\/invite)\/.+[a-z]/gi;
const generalLinkRegex = /(https?:\/\/[^\s]+)/gi;

// ============================================================
// ✅ [NEW - Part 3] Smart Sending Function
// ============================================================
const buildDMPayloadGlobal = (userId, settings) => {
    const { style, msgContent, caption, imageUrl, color, showDeleteButton } = settings;

    const components = [];
    if (showDeleteButton) {
        components.push(new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`delete_dm_${userId}`)
                .setLabel('Delete Message 🗑️')
                .setStyle(ButtonStyle.Danger)
        ));
    }

    if (style === 'embed') {
        const embed = new EmbedBuilder().setColor(color || '#3498db').setTimestamp();
        if (msgContent) embed.setDescription(msgContent);
        if (caption)    embed.setTitle(caption);
        if (imageUrl)   embed.setImage(imageUrl);
        return { embeds: [embed], components };
    } else {
        const payload = {
            content: [msgContent, caption].filter(Boolean).join('\n') || ' ',
            components
        };
        if (imageUrl) payload.files = [imageUrl];
        return payload;
    }
};

const executeSmartSend = async (user, initiator, settings) => {
    try {
        const dmChannel = await user.createDM();
        const payload = buildDMPayloadGlobal(user.id, settings);
        const sent = await dmChannel.send(payload);

        const msgLink = `https://discord.com/channels/@me/${sent.channelId}/${sent.id}`;
        const logCh = client.channels.cache.get(CONFIG.DM_LOG_CH);
        if (logCh) {
            await logCh.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#2b2d31')
                        .setTitle('🔗 DM Tracking Link')
                        .setDescription(`**Sent to:** ${user.username}\n\n${msgLink}`)
                        .setTimestamp()
                ]
            }).catch(() => {});
        }

        if (settings.reactionEmoji) {
            await sent.react(settings.reactionEmoji).catch(() => {});
        }

        await logDMActivity(user.id, user.tag, settings.msgContent || settings.caption || '[📷 Image Only]', 'AI_RESPONSE');

        if (settings.delAfter > 0) {
            setTimeout(() => sent.delete().catch(() => {}), settings.delAfter * 60000);
        }
        return true;
    } catch (e) {
        console.error(`❌ executeSmartSend failed for ${user.username}:`, e);
        return false;
    }
};

async function sendAnonymousDM(targetUser, initiator, messageContent) {
    try {
        const sent = await targetUser.send({ content: messageContent });
        const trackingLink = `https://discord.com/channels/@me/${sent.channelId}/${sent.id}`;
        await initiator.send({
            embeds: [
                new EmbedBuilder()
                    .setColor('#2b2d31')
                    .setTitle('🔗 Tracking Link Generated')
                    .setDescription(`**Sent to:** ${targetUser.username}\n\n${trackingLink}`)
            ]
        });
    } catch (err) {
        console.log(`Could not DM ${targetUser.tag}`);
    }
}

// --- Command Registration ---
const commands = [
    new SlashCommandBuilder().setName('ping').setDescription('Bot latency speed'),
    new SlashCommandBuilder().setName('clear').setDescription('Clear the chat').addIntegerOption(o => o.setName('amount').setDescription('Number of messages').setRequired(true)),
    new SlashCommandBuilder().setName('send').setDescription('Send a custom message with specific time').addStringOption(o => o.setName('message').setDescription('Message content').setRequired(true)).addStringOption(o => o.setName('style').setDescription('Message style').setRequired(true).addChoices({name:'Box (Embed)',value:'embed'},{name:'Normal',value:'normal'})).addIntegerOption(o => o.setName('delay_send').setDescription('Wait time before sending (minutes)').setRequired(true)).addIntegerOption(o => o.setName('delete_after').setDescription('Auto-delete time (minutes)').setRequired(true)).addStringOption(o => o.setName('color').setDescription('Box color').addChoices({name:'Blue',value:'#3498db'},{name:'Red',value:'#e74c3c'},{name:'Green',value:'#2ecc71'})),
    new SlashCommandBuilder().setName('ads_set').setDescription('Setup a new auto-ad').addStringOption(o => o.setName('name').setDescription('Ad name').setRequired(true)).addStringOption(o => o.setName('text').setDescription('Ad content').setRequired(true)).addChannelOption(o => o.setName('channel').setDescription('Ad channel').addChannelTypes(ChannelType.GuildText).setRequired(true)).addIntegerOption(o => o.setName('interval').setDescription('Send every X minutes').setRequired(true)).addIntegerOption(o => o.setName('delete').setDescription('Delete after X minutes').setRequired(true)).addStringOption(o => o.setName('style').setDescription('Style').setRequired(true).addChoices({name:'Box',value:'embed'},{name:'Normal',value:'normal'})),
    new SlashCommandBuilder().setName('ads_edit').setDescription('Edit or delete an existing ad').addStringOption(o => o.setName('name').setDescription('Choose ad name').setRequired(true).setAutocomplete(true)).addStringOption(o => o.setName('text').setDescription('New text (optional)').setRequired(false)).addChannelOption(o => o.setName('channel').setDescription('New channel (optional)').addChannelTypes(ChannelType.GuildText).setRequired(false)).addIntegerOption(o => o.setName('interval').setDescription('New interval (optional)').setRequired(false)).addIntegerOption(o => o.setName('delete').setDescription('New delete time (optional)').setRequired(false)).addStringOption(o => o.setName('style').setDescription('New style (optional)').setRequired(false).addChoices({name:'Box',value:'embed'},{name:'Normal',value:'normal'})),
    new SlashCommandBuilder().setName('translate').setDescription('Translate text').addStringOption(o => o.setName('text').setDescription('The text').setRequired(true)).addStringOption(o => o.setName('to').setDescription('Language code (e.g: ar)').setRequired(true)),
    new SlashCommandBuilder().setName('vote').setDescription('Make a quick vote').addStringOption(o => o.setName('question').setDescription('Vote question').setRequired(true)),
    new SlashCommandBuilder().setName('role').setDescription('Select a member and a rank').addUserOption(o => o.setName('user').setDescription('The member to give the rank to').setRequired(true)).addRoleOption(o => o.setName('rank').setDescription('The rank to give').setRequired(true)),
    new SlashCommandBuilder().setName('slash_control').setDescription('Restrict a command to a specific role').addStringOption(o => o.setName('command_name').setDescription('The command to restrict').setRequired(true)).addRoleOption(o => o.setName('allowed_role').setDescription('The role allowed to use this command').setRequired(true)),
    new SlashCommandBuilder()
        .setName('reaction')
        .setDescription('Manage reactions on messages')
        .addSubcommand(sub =>
            sub.setName('add')
                .setDescription('Add a reaction to a specific message using its link')
                .addStringOption(o => o.setName('link').setDescription('The message link').setRequired(true))
                .addStringOption(o => o.setName('emoji').setDescription('The emoji to react with').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('remove')
                .setDescription('Remove a specific reaction from a message using its link')
                .addStringOption(o => o.setName('message_link').setDescription('The link of the message').setRequired(true))
        ),
    new SlashCommandBuilder()
        .setName('picture')
        .setDescription('Send pictures with auto-send and auto-delete timers')
        .addAttachmentOption(o => o.setName('image').setDescription('The main image to send').setRequired(true))
        .addStringOption(o => o.setName('style').setDescription('Message style').setRequired(true).addChoices({name:'Box (Embed)',value:'embed'},{name:'Normal',value:'normal'}))
        .addIntegerOption(o => o.setName('delay_send').setDescription('Wait time before sending (minutes)').setRequired(true))
        .addIntegerOption(o => o.setName('delete_after').setDescription('Auto-delete time (minutes)').setRequired(true))
        .addStringOption(o => o.setName('caption').setDescription('Add a text description with the image').setRequired(false)),

    // ============================================================
    // ✅ /dm Command
    // ============================================================
    new SlashCommandBuilder()
        .setName('dm')
        .setDescription('Full DM control panel — send messages or images to users via DM')
        .addStringOption(o => o.setName('style').setDescription('Message style').setRequired(true).addChoices({name:'Box (Embed)',value:'embed'},{name:'Normal',value:'normal'}))
        .addIntegerOption(o => o.setName('delay_send').setDescription('Wait time before sending (minutes, 0 = instant)').setRequired(true))
        .addIntegerOption(o => o.setName('delete_after').setDescription('Auto-delete after X minutes (0 = never)').setRequired(true))
        .addUserOption(o => o.setName('user').setDescription('Target a specific user directly (no selector UI)').setRequired(false))
        .addBooleanOption(o => o.setName('everyone').setDescription('Send to ALL members — a selector will open to pick who to EXCLUDE').setRequired(false))
        .addStringOption(o => o.setName('message').setDescription('Message text content').setRequired(false))
        .addAttachmentOption(o => o.setName('image').setDescription('Image to send in DM').setRequired(false))
        .addStringOption(o => o.setName('caption').setDescription('Caption text for the image').setRequired(false))
        .addStringOption(o => o.setName('color').setDescription('Embed box color').addChoices({name:'Blue',value:'#3498db'},{name:'Red',value:'#e74c3c'},{name:'Green',value:'#2ecc71'},{name:'Gold',value:'#f1c40f'}).setRequired(false))
        .addIntegerOption(o => o.setName('repeat_interval').setDescription('Repeat DM every X minutes (0 = no repeat)').setRequired(false))
        .addStringOption(o => o.setName('reaction').setDescription('Emoji to auto-react on the DM message').setRequired(false))
        .addBooleanOption(o => o.setName('delete_button').setDescription('Show a red Delete button to the recipient (default: off)').setRequired(false)),

    // ============================================================
    // ✅ /edit Command
    // ============================================================
    new SlashCommandBuilder()
        .setName('edit')
        .setDescription('Edit a previously sent bot message using its link')
        .addStringOption(o => o.setName('message_link').setDescription('The full message link to edit').setRequired(true)),

    new SlashCommandBuilder()
        .setName('delete')
        .setDescription('Delete a message using its link')
        .addStringOption(opt => 
            opt.setName('message_link')
               .setDescription('Paste the message link here')
               .setRequired(true)
        ),

    new SlashCommandBuilder()
        .setName('check')
        .setDescription('Get a full private status report of the server'),

    // ============================================================
    // ✅ [UPGRADED] /setup-form Command — Custom field names,
    //    custom message above button, embed/normal control
    // ============================================================
    new SlashCommandBuilder()
        .setName('setup-form')
        .setDescription('Create a fully customized form with your own message and field names')
        .addStringOption(opt => opt.setName('message_text').setDescription('The text to show above the button').setRequired(true))
        .addBooleanOption(opt => opt.setName('is_box').setDescription('Send this message in a Box (Embed)?').setRequired(true))
        .addStringOption(opt => opt.setName('btn_name').setDescription('Button Name').setRequired(true))
        .addStringOption(opt => opt.setName('btn_color').setDescription('Primary, Success, Danger, Secondary').setRequired(true)
            .addChoices(
                { name: 'Blue',      value: 'Primary'   },
                { name: 'Green',     value: 'Success'   },
                { name: 'Red',       value: 'Danger'    },
                { name: 'Grey',      value: 'Secondary' }
            ))
        .addChannelOption(opt => opt.setName('target_channel').setDescription('Where results will be sent').setRequired(true))
        .addStringOption(opt => opt.setName('field_1_name').setDescription('Name for Field 1').setRequired(true))
        .addBooleanOption(opt => opt.setName('result_is_box').setDescription('Send result as Embed box?').setRequired(true))
        .addStringOption(opt => opt.setName('field_2_name').setDescription('Name for Field 2 (Optional)').setRequired(false))
        .addStringOption(opt => opt.setName('field_3_name').setDescription('Name for Field 3 (Optional)').setRequired(false))
        .addStringOption(opt => opt.setName('field_4_name').setDescription('Name for Field 4 (Optional)').setRequired(false))
        .addStringOption(opt => opt.setName('field_5_name').setDescription('Name for Field 5 (Optional)').setRequired(false))
        .addBooleanOption(opt => opt.setName('send_to_dm').setDescription('Send the form button to a user DM instead of here').setRequired(false))
        .addUserOption(opt => opt.setName('dm_user').setDescription('The user to send the form button to (required if send_to_dm is true)').setRequired(false)),

    new SlashCommandBuilder()
        .setName('lockdown')
        .setDescription('🔒 Lock or unlock all server channels in an emergency')
        .addStringOption(o => o.setName('action').setDescription('lock or unlock').setRequired(true)
            .addChoices({ name: '🔒 Lock All', value: 'lock' }, { name: '🔓 Unlock All', value: 'unlock' }))
        .addStringOption(o => o.setName('reason').setDescription('Reason for lockdown').setRequired(false)),

    // ============================================================
    // ✅ Message Context Menu Commands (Apps Menu)
    // ============================================================
    new ContextMenuCommandBuilder()
        .setName('Delete Message')
        .setType(ApplicationCommandType.Message),

    new ContextMenuCommandBuilder()
        .setName('Edit Message')
        .setType(ApplicationCommandType.Message),

    new ContextMenuCommandBuilder()
        .setName('Add Reaction')
        .setType(ApplicationCommandType.Message),

    new ContextMenuCommandBuilder()
        .setName('Remove Reaction')
        .setType(ApplicationCommandType.Message),

].map(c => c.toJSON());

function startAdLoop(adName, guildId) {
    const ad = adsStorage.get(adName);
    if (!ad) return;
    if (ad.timer) clearInterval(ad.timer);
    ad.timer = setInterval(async () => {
        const guild = client.guilds.cache.get(guildId);
        const chan = guild?.channels.cache.get(ad.channelId);
        if (!chan) return;
        if (ad.lastMsgId) {
            const old = await chan.messages.fetch(ad.lastMsgId).catch(() => null);
            if (old) await old.delete().catch(() => {});
        }
        let sent;
        if (ad.style === 'embed') { sent = await chan.send({ embeds: [new EmbedBuilder().setDescription(ad.text).setColor('#3498db').setTitle(`📢 ${ad.name}`)] }).catch(() => {}); }
        else { sent = await chan.send(`**📢 ${ad.name}**\n\n${ad.text}`).catch(() => {}); }
        if (sent) { ad.lastMsgId = sent.id; if (ad.deleteAfter > 0) setTimeout(() => sent.delete().catch(() => {}), ad.deleteAfter * 60000); }
    }, ad.interval * 60000);
}

function startDMAdsLoop(adName, guildId) {
    const ad = dmAdsStorage.get(adName);
    if (!ad) return;
    if (ad.timer) clearInterval(ad.timer);

    ad.timer = setInterval(async () => {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) return;

        const buildPayload = (userId) => {
            const deleteRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`delete_dm_${userId}`)
                    .setLabel('Delete Message 🗑️')
                    .setStyle(ButtonStyle.Danger)
            );

            if (ad.style === 'embed') {
                const embed = new EmbedBuilder()
                    .setColor(ad.color || '#3498db')
                    .setTimestamp();
                if (ad.msgContent) embed.setDescription(ad.msgContent);
                if (ad.caption) embed.setTitle(ad.caption);
                if (ad.imageUrl) embed.setImage(ad.imageUrl);
                return { embeds: [embed], components: [deleteRow] };
            } else {
                const payload = { 
                    content: ad.msgContent || ad.caption || ' ',
                    components: [deleteRow]
                };
                if (ad.imageUrl) payload.files = [ad.imageUrl];
                return payload;
            }
        };

        const sendOne = async (user) => {
            try {
                const dm = await user.createDM();
                const payload = buildPayload(user.id);
                const sent = await dm.send(payload);
                
                if (ad.reactionEmoji) {
                    await sent.react(ad.reactionEmoji).catch(() => {});
                }

                await logDMActivity(user.id, user.tag, ad.msgContent || '[Image]', 'AI_RESPONSE');
                if (ad.deleteAfter > 0) setTimeout(() => sent.delete().catch(() => {}), ad.deleteAfter * 60000);
            } catch (e) {
                console.error(`❌ DM Ad failed for ${user.tag}:`, e);
            }
        };

        if (ad.targetUserId === 'everyone') {
            const members = await guild.members.fetch().catch(() => null);
            if (!members) return;
            for (const [, member] of members) {
                if (!member.user.bot) {
                    await sendOne(member.user);
                    await new Promise(r => setTimeout(r, 1200));
                }
            }
        } else {
            const user = await client.users.fetch(ad.targetUserId).catch(() => null);
            if (user) await sendOne(user);
        }

    }, ad.interval * 60000);
}

// --- Monitoring Events ---
client.on('guildUpdate', (oldGuild, newGuild) => {
    if (oldGuild.name !== newGuild.name) sendDetailedLog(newGuild, 'Server Name Changed', `From **${oldGuild.name}** to **${newGuild.name}**`, '#e67e22');
    if (oldGuild.icon !== newGuild.icon) sendDetailedLog(newGuild, 'Server Icon Changed', `Server avatar has been updated.`, '#9b59b6');
});

client.on('guildMemberUpdate', async (oldMember, newMember) => {

    if (!oldMember.premiumSince && newMember.premiumSince) {
        const BOOST_ROLE_ID = '1496789784524357703';
        const BOOST_CHANNEL_ID = '1482934834899714048';

        try {
            await newMember.roles.add(BOOST_ROLE_ID);
        } catch (err) {
            console.error("Failed to assign boost role:", err);
        }

        const boostChannel = newMember.guild.channels.cache.get(BOOST_CHANNEL_ID);
        if (boostChannel) {
            const boostMsg = await boostChannel.send({
                content: `@everyone\n<@${newMember.id}> Boosted the server! 🎉\n- Now <@${newMember.id}> have <@&${BOOST_ROLE_ID}> rank!`
            });
            if (boostMsg) await boostMsg.react('🎉').catch(() => {});
        }

        await sendModDM(
            newMember.user,
            '💎 Server Boost Reward',
            `Thank you for boosting **${newMember.guild.name}**! Your boost role has been assigned. We truly appreciate your support! 🎉`,
            newMember.guild.name
        );

        sendDetailedLog(
            newMember.guild, 
            'Server Boosted! 💎', 
            `User: <@${newMember.id}> has just boosted the server.\nStatus: **Role Assigned Successfully**`, 
            '#ffff55' 
        );
    }

    const wasTimedOut = !oldMember.communicationDisabledUntil && newMember.communicationDisabledUntil;
    if (wasTimedOut) {
        const until = newMember.communicationDisabledUntil;
        const duration = until ? `until <t:${Math.floor(until.getTime() / 1000)}:R>` : 'temporarily';
        await sendModDM(
            newMember.user,
            '🤐 Timeout (Muted)',
            `You have been muted in **${newMember.guild.name}** ${duration}.\nReason: Violation of server rules.`,
            newMember.guild.name
        );
    }

    if (oldMember.nickname !== newMember.nickname) {
        sendDetailedLog(newMember.guild, 'Nickname Changed', `User: <@${newMember.id}>\nOld: \`${oldMember.nickname || 'None'}\`\nNew: \`${newMember.nickname || 'Original'}\``);
    }
    const addedRoles = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
    const removedRoles = oldMember.roles.cache.filter(r => !newMember.roles.cache.has(r.id));
    if (addedRoles.size > 0) sendDetailedLog(newMember.guild, 'Role Added', `Role <@&${addedRoles.first().id}> added to <@${newMember.id}>`, '#2ecc71');
    if (removedRoles.size > 0) sendDetailedLog(newMember.guild, 'Role Removed', `Role <@&${removedRoles.first().id}> removed from <@${newMember.id}>`, '#e74c3c');
});

client.on('channelCreate', (ch) => sendDetailedLog(ch.guild, 'Channel Created', `Name: **${ch.name}** (Type: ${ch.type})`, '#2ecc71'));
client.on('channelDelete', (ch) => sendDetailedLog(ch.guild, 'Channel Deleted', `Name: **${ch.name}**`, '#e74c3c'));
client.on('roleCreate', (role) => sendDetailedLog(role.guild, 'Role Created', `Role: **${role.name}**`, '#2ecc71'));
client.on('roleDelete', (role) => sendDetailedLog(role.guild, 'Role Deleted', `Role: **${role.name}**`, '#e74c3c'));

client.on('guildBanAdd', async (ban) => {
    await sendModDM(
        ban.user,
        '🚫 Permanent Ban',
        `You have been permanently banned from **${ban.guild.name}**.\nReason: ${ban.reason || 'Violation of server rules.'}`,
        ban.guild.name
    );
    sendDetailedLog(ban.guild, 'Member Banned', `User: **${ban.user.tag}** was banned.`, '#c0392b');
});

// ============================================================
// --- ✅ [3] The Observer System (Voice & Message Activity) ---
// ============================================================
client.on('voiceStateUpdate', (oldState, newState) => {
    const member = newState.member;
    const guild = newState.guild;

    if (!oldState.channelId && newState.channelId) {
        const channel = guild.channels.cache.get(newState.channelId);
        sendDetailedLog(guild, 'Voice Join', 
            `👤 <@${member.id}> joined voice channel: **${channel.name}**`, '#2ecc71');
    }

    if (oldState.channelId && !newState.channelId) {
        const channel = guild.channels.cache.get(oldState.channelId);
        sendDetailedLog(guild, 'Voice Leave', 
            `👤 <@${member.id}> left voice channel: **${channel.name}**`, '#e74c3c');
    }

    if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
        const oldChannel = guild.channels.cache.get(oldState.channelId);
        const newChannel = guild.channels.cache.get(newState.channelId);
        sendDetailedLog(guild, 'Voice Move', 
            `👤 <@${member.id}> moved from **${oldChannel.name}** to **${newChannel.name}**`, '#f1c40f');
    }

    if (!oldState.selfDeaf && newState.selfDeaf) {
        sendDetailedLog(guild, 'Member Deafen', `<@${member.id}> turned on **Server Deafen**.`, '#95a5a6');
    }
});

client.on('messageDelete', (message) => {
    if (!message.author || message.author.bot) return;
    if (!message.guild) return;
    sendDetailedLog(message.guild, 'Message Deleted', 
        `🗑️ Message by <@${message.author.id}> deleted in <#${message.channel.id}>:\n**Content:** ${message.content || "Empty/Image"}`, '#e74c3c');
});

client.on('messageUpdate', (oldMessage, newMessage) => {
    if (!oldMessage.author || oldMessage.author.bot || oldMessage.content === newMessage.content) return;
    sendDetailedLog(oldMessage.guild, 'Message Edited', 
        `📝 <@${oldMessage.author.id}> edited message in <#${oldMessage.channel.id}>:\n**Old:** ${oldMessage.content}\n**New:** ${newMessage.content}`, '#3498db');
});

client.on('messageReactionAdd', async (reaction, user) => {
    if (user.bot) return;

    if (reaction.partial) {
        try { await reaction.fetch(); } catch (e) { return; }
    }

    if (reaction.message.channel.type === ChannelType.DM) {
        await logDMActivity(
            user.id,
            user.tag || user.username,
            `✨ User reacted with **${reaction.emoji.name}** to a DM message (ID: ${reaction.message.id})`,
            'ALERT'
        );
    }
});

client.on('ready', async () => {
    const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
    try { await rest.put(Routes.applicationCommands(client.user.id), { body: commands }); } catch (e) { console.error(e); }
    console.log(`Logged in as ${client.user.tag}`);
    updateLiveInfo();
});

// ============================================================
// --- Main messageCreate (Automod + Anti-Link + AI Brain + DM Logger) ---
// ============================================================
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    if (message.channel.type === ChannelType.DM) {
        if (message.attachments.size > 0) {
            const attachment = message.attachments.first();
            await logDMActivity(message.author.id, message.author.username, '', 'IN_MEDIA', { imageUrl: attachment.url });
        } else {
            await logDMActivity(message.author.id, message.author.username, message.content, 'IN_TEXT');
        }
        try {
            await message.channel.sendTyping();
            const fakeGuild = { memberCount: '?', name: 'DM', members: { cache: new Map() } };
            const text = await getEliteAIResponse(message.author.id, message.content, fakeGuild);
            if (text) {
                const chunks = [];
                for (let i = 0; i < text.length; i += 1900) chunks.push(text.slice(i, i + 1900));
                for (const chunk of chunks) await message.reply(chunk);
            }
        } catch (e) { console.error(e); }
        return;
    }

    if (!message.guild) return;

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {

        // ── Anti-Spam ──────────────────────────────────────────
        const spamData = spamTracker.get(message.author.id) || { count: 0, timer: null };
        spamData.count++;
        if (spamData.timer) clearTimeout(spamData.timer);
        spamData.timer = setTimeout(() => spamTracker.delete(message.author.id), SPAM_WINDOW);
        spamTracker.set(message.author.id, spamData);

        if (spamData.count >= SPAM_LIMIT) {
            spamTracker.delete(message.author.id);
            await message.member.timeout(10 * 60 * 1000, 'Spam detected').catch(() => {});
            const spamEmbed = new EmbedBuilder()
                .setTitle('🚫 Anti-Spam System')
                .setDescription(`<@${message.author.id}> تم إسكاتك لمدة **10 دقائق** بسبب الإرسال السريع المتكرر.`)
                .setColor('#e74c3c').setTimestamp();
            const sm = await message.channel.send({ embeds: [spamEmbed] });
            setTimeout(() => sm.delete().catch(() => {}), 8000);
            await sendModDM(message.member.user, '🚫 Anti-Spam', 'تم إسكاتك 10 دقائق بسبب الإرسال السريع. تمهل قليلاً!', message.guild.name);
            sendDetailedLog(message.guild, 'Anti-Spam Triggered', `<@${message.author.id}> أرسل رسائل بسرعة كبيرة — تم timeout 10 دقائق.`, '#e67e22');
            return;
        }

        // ── Anti-Mass-Mention ──────────────────────────────────
        const mentionCount = message.mentions.users.size + message.mentions.roles.size;
        if (mentionCount >= 5) {
            await message.delete().catch(() => {});
            await message.member.ban({ reason: 'Mass mention / Mention spam' }).catch(() => {});
            const mmEmbed = new EmbedBuilder()
                .setTitle('🚫 Anti-Mass-Mention')
                .setDescription(`تم حظر <@${message.author.id}> بسبب الـ mention spam (${mentionCount} mention في رسالة واحدة).`)
                .setColor('#c0392b').setTimestamp();
            const mm = await message.channel.send({ embeds: [mmEmbed] });
            setTimeout(() => mm.delete().catch(() => {}), 10000);
            sendDetailedLog(message.guild, 'Mass Mention Ban', `<@${message.author.id}> تم حظره — ${mentionCount} mention في رسالة.`, '#c0392b');
            return;
        }

        // ── Anti-Caps ──────────────────────────────────────────
        const msgContent = message.content;
        if (msgContent.length > 10) {
            const upperCount = (msgContent.match(/[A-Z]/g) || []).length;
            const letterCount = (msgContent.match(/[a-zA-Z]/g) || []).length;
            if (letterCount > 5 && upperCount / letterCount > 0.8) {
                await message.delete().catch(() => {});
                const capsEmbed = new EmbedBuilder()
                    .setTitle('⚠️ Anti-Caps System')
                    .setDescription(`<@${message.author.id}> الرجاء عدم الكتابة بحروف كبيرة بشكل مبالغ فيه.`)
                    .setColor('#f39c12').setTimestamp();
                const cm = await message.channel.send({ embeds: [capsEmbed] });
                setTimeout(() => cm.delete().catch(() => {}), 6000);
                return;
            }
        }

    }

    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        const content = message.content.toLowerCase();

        inviteLinkRegex.lastIndex = 0;
        generalLinkRegex.lastIndex = 0;

        const hasInvite = inviteLinkRegex.test(content);
        const hasLink = generalLinkRegex.test(content);
        const bypassAttempt = content.includes('discord . gg') || content.includes('dot com') || content.includes('. gg/');

        if (hasInvite || bypassAttempt || hasLink) {
            await message.delete().catch(() => {});

            let warns = (warnStorage.get(message.author.id) || 0) + 1;
            warnStorage.set(message.author.id, warns);

            if (warns === 1) {
                await sendModDM(message.member.user, '⚠️ Warning — Unauthorized Link', 'You sent an unauthorized link or advertisement. This is your first warning. Next violation will result in a timeout.', message.guild.name);

                const warnEmbed = new EmbedBuilder()
                    .setTitle('🚫 Security Violation')
                    .setDescription(`Stop right there <@${message.author.id}>! Advertising or sending unauthorized links is strictly forbidden.`)
                    .setColor('#e74c3c')
                    .setFooter({ text: 'Next violation will result in a timeout.' });
                const m = await message.channel.send({ embeds: [warnEmbed] });
                setTimeout(() => m.delete().catch(() => {}), 10000);

            } else if (warns === 2) {
                await message.member.timeout(60 * 60 * 1000, 'Sending links/Advertising').catch(() => {});
                await sendModDM(message.member.user, '🤐 Timeout — 1 Hour', 'You have been muted for 1 hour for repeatedly sending unauthorized links or advertisements.', message.guild.name);
                message.channel.send(`🤐 <@${message.author.id}> has been muted for 1 hour for repeated link violations.`);

            } else {
                await sendModDM(message.member.user, '🚫 Permanent Ban', 'You have been permanently banned for persistent advertising and security breaches.', message.guild.name);
                await message.member.ban({ reason: 'Persistent Advertising & Security Breach' }).catch(() => {});
                message.channel.send(`🚫 <@${message.author.id}> has been permanently banned for extreme advertising.`);
                sendDetailedLog(message.guild, 'User Banned (Anti-Link)', `User: **${message.author.tag}** was banned for trying to bypass link security.`, '#c0392b');
            }
            return;
        }
    }

    const hasBadWord = BAD_WORDS.some(word => message.content.toLowerCase().includes(word));
    if (hasBadWord) {
        await message.delete().catch(() => {});
        let count = (warnStorage.get(message.author.id) || 0) + 1;
        warnStorage.set(message.author.id, count);
        if (count === 1) {
            await message.member.timeout(5 * 60 * 1000, 'Swearing in server').catch(() => {});
            await sendModDM(message.member.user, '🤐 Timeout — 5 Minutes', 'You have been muted for 5 minutes for using inappropriate language in the server.', message.guild.name);
            const m = await message.channel.send(`⚠️ <@${message.author.id}>, you have been muted for 5 minutes for swearing.`);
            setTimeout(() => m.delete().catch(() => {}), 10000);
        } else {
            await sendModDM(message.member.user, '🚫 Permanent Ban', 'You have been permanently banned for repeated use of inappropriate language.', message.guild.name);
            await message.member.ban({ reason: 'Repeated severe swearing' }).catch(() => {});
            message.channel.send(`🚫 <@${message.author.id}> has been permanently banned for repeated swearing.`);
        }
        return;
    }

    const isHelpChannel = message.channel.id === CONFIG.HELP_CH;
    const isMentioned = message.mentions.users.has(client.user.id) && !message.mentions.everyone;
    const cleanContent = message.content.replace(`<@${client.user.id}>`, '').replace(`<@!${client.user.id}>`, '').trim();
    const shouldRespond = isHelpChannel || isMentioned;

    if (shouldRespond) {
        try {
            await message.channel.sendTyping();

            const text = await getEliteAIResponse(message.author.id, cleanContent || message.content, message.guild);
            
            if (text) {
                const chunks = [];
                for (let i = 0; i < text.length; i += 1900) {
                    chunks.push(text.slice(i, i + 1900));
                }

                const isUpdateTask = cleanContent.includes("تعديل") || cleanContent.includes("update") || cleanContent.includes("ضيف");

                const sentBotMsgs = [];

                if (isUpdateTask) {
                    pendingUpdates.set(message.author.id, cleanContent);
                    const row = new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('open_admin_modal').setLabel('Enter Password 🔐').setStyle(ButtonStyle.Danger)
                    );
                    sentBotMsgs.push(await message.reply({ content: chunks[0], components: [row] }));
                    for (let i = 1; i < chunks.length; i++) sentBotMsgs.push(await message.channel.send(chunks[i]));
                } else {
                    sentBotMsgs.push(await message.reply(chunks[0]));
                    for (let i = 1; i < chunks.length; i++) sentBotMsgs.push(await message.channel.send(chunks[i]));
                }

                if (isHelpChannel) {
                    setTimeout(() => {
                        message.delete().catch(() => {});
                        sentBotMsgs.forEach(m => m.delete().catch(() => {}));
                    }, 5 * 60 * 1000);
                }
            }

            const rankKeywords = ['rank', 'role', 'رتبة', 'رتبه', 'رتب'];
            if (rankKeywords.some(key => message.content.toLowerCase().includes(key))) {
                const embed = new EmbedBuilder().setDescription("Submit to write your username on Xbox to get rank you want it. By @pro_king510").setColor('#3498db');
                const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('open_rank_modal').setLabel('Submit').setStyle(ButtonStyle.Primary));
                const sentModalMsg = await message.channel.send({ embeds: [embed], components: [row] });
                if (isHelpChannel) setTimeout(() => sentModalMsg.delete().catch(() => {}), 300000);
            }
        } catch (e) { console.error(e); }
    }
});

client.on('interactionCreate', async (interaction) => {

    // ============================================================
    // ✅ Message Context Menu Commands (Apps Menu)
    // ============================================================
    if (interaction.isMessageContextMenuCommand()) {
        const targetMessage = interaction.targetMessage;

        if (interaction.commandName === 'Delete Message') {
            try {
                await targetMessage.delete();
                await interaction.reply({ content: '✅ Message deleted successfully!', ephemeral: true });
            } catch (error) {
                let errorMessage = '❌ Could not delete the message.';
                if (error.code === 50013) errorMessage = "❌ I don't have permission to delete this message (Need 'Manage Messages').";
                if (error.code === 10008) errorMessage = '❌ Message not found. It might be already deleted.';
                if (error.code === 50005) errorMessage = '❌ I cannot delete someone else\'s message in DMs!';
                await interaction.reply({ content: errorMessage, ephemeral: true });
            }
            return;
        }

        if (interaction.commandName === 'Edit Message') {
            const oldText = targetMessage.embeds.length > 0
                ? (targetMessage.embeds[0].description || '')
                : (targetMessage.content || '');

            const modal = new ModalBuilder()
                .setCustomId(`smart_edit_${targetMessage.channelId}_${targetMessage.id}`)
                .setTitle('Edit Message');

            const input = new TextInputBuilder()
                .setCustomId('updated_text')
                .setLabel('Edit Content:')
                .setStyle(TextInputStyle.Paragraph)
                .setValue(oldText)
                .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(input));
            return await interaction.showModal(modal);
        }

        if (interaction.commandName === 'Add Reaction') {
            const modal = new ModalBuilder()
                .setCustomId(`reaction_ctx_${targetMessage.channelId}_${targetMessage.id}`)
                .setTitle('Add Reaction');

            const input = new TextInputBuilder()
                .setCustomId('reaction_emoji')
                .setLabel('Emoji to react with:')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(input));
            return await interaction.showModal(modal);
        }

        if (interaction.commandName === 'Remove Reaction') {
            const reactions = targetMessage.reactions.cache;
            if (reactions.size === 0) {
                return await interaction.reply({ content: '❌ No reactions found on this message.', ephemeral: true });
            }
            const selectOptions = reactions.map(r => ({
                label: `Remove ${r.emoji.name}`,
                description: `Count: ${r.count}`,
                value: r.emoji.id || r.emoji.name,
                emoji: r.emoji.id ? { id: r.emoji.id } : { name: r.emoji.name }
            }));
            const selector = new StringSelectMenuBuilder()
                .setCustomId(`delete_reaction_${targetMessage.channelId}_${targetMessage.id}`)
                .setPlaceholder('Choose the reaction to remove...')
                .addOptions(selectOptions);
            return await interaction.reply({
                content: '🔍 Select the reaction you want to remove:',
                components: [new ActionRowBuilder().addComponents(selector)],
                ephemeral: true
            });
        }

        return;
    }

    // ============================================================
    // ✅ [UPDATED] Delete DM Button
    // ============================================================
    if (interaction.isButton() && interaction.customId.startsWith('delete_dm_')) {
        const targetId = interaction.customId.replace('delete_dm_', '');
        if (interaction.user.id === targetId) {
            await logDMActivity(
                interaction.user.id,
                interaction.user.tag || interaction.user.username,
                `🗑️ User deleted the DM message using the Delete button (Message ID: ${interaction.message.id})`,
                'ALERT'
            );
            await interaction.message.delete().catch(() => {});
        } else {
            await interaction.reply({ content: '❌ You are not authorized to delete this message.', ephemeral: true });
        }
        return;
    }

    if (interaction.isButton() && interaction.customId === 'open_rank_modal') {
        const modal = new ModalBuilder().setCustomId('rank_modal').setTitle('Rank Request');
        const userField = new TextInputBuilder().setCustomId('xbox_user').setLabel("Username").setStyle(TextInputStyle.Short).setPlaceholder("Write your Xbox username").setRequired(true);
        const rankField = new TextInputBuilder().setCustomId('rank_type').setLabel("Rank you want").setStyle(TextInputStyle.Short).setPlaceholder("Write the rank name").setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(userField), new ActionRowBuilder().addComponents(rankField));
        return await interaction.showModal(modal);
    }

    if (interaction.isButton() && interaction.customId === 'open_admin_modal') {
        const modal = new ModalBuilder().setCustomId('admin_pass_modal').setTitle('Admin Verification');
        const passField = new TextInputBuilder().setCustomId('admin_password_input').setLabel("Admin Password").setStyle(TextInputStyle.Short).setPlaceholder("Enter Pro Robot Password").setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(passField));
        return await interaction.showModal(modal);
    }

    // ============================================================
    // ✅ [UPGRADED] Dynamic form button handler (form_<timestamp>)
    //    Opens a modal with the custom field names the admin chose
    // ============================================================
    if (interaction.isButton() && interaction.customId.startsWith('form_') && !interaction.customId.startsWith('form_start_')) {
        const formSettings = formSettingsDB.get(interaction.customId);
        if (!formSettings) {
            return await interaction.reply({ content: '❌ This form has expired or was not found.', ephemeral: true });
        }

        const modal = new ModalBuilder()
            .setCustomId(`submit_${interaction.customId}`)
            .setTitle('Server Form');

        formSettings.fields.forEach((fieldName, index) => {
            const field = new TextInputBuilder()
                .setCustomId(`custom_field_${index}`)
                .setLabel(fieldName)
                .setStyle(index === 0 ? TextInputStyle.Short : TextInputStyle.Paragraph)
                .setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(field));
        });

        return await interaction.showModal(modal);
    }

    // ============================================================
    // ✅ [LEGACY] form_start_ Button — Opens the old submission modal
    // ============================================================
    if (interaction.isButton() && interaction.customId.startsWith('form_start_')) {
        const targetChannelId = interaction.customId.split('_')[2];

        const modal = new ModalBuilder()
            .setCustomId(`submit_modal_${targetChannelId}`)
            .setTitle('Custom Submission Form');

        const nameField = new TextInputBuilder()
            .setCustomId('user_name')
            .setLabel('Enter your name:')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Type here...')
            .setRequired(true);

        const detailsField = new TextInputBuilder()
            .setCustomId('user_details')
            .setLabel('Details / Description:')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false);

        modal.addComponents(
            new ActionRowBuilder().addComponents(nameField),
            new ActionRowBuilder().addComponents(detailsField)
        );

        return await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('reaction_ctx_')) {
        const parts = interaction.customId.split('_');
        const chId  = parts[2];
        const msgId = parts[3];
        const emoji = interaction.fields.getTextInputValue('reaction_emoji');
        try {
            const targetChannel = await client.channels.fetch(chId).catch(() => null);
            const targetMsg = await targetChannel.messages.fetch(msgId).catch(() => null);
            await targetMsg.react(emoji);
            await interaction.reply({ content: `✅ Reacted with ${emoji}!`, ephemeral: true });
        } catch (e) {
            await interaction.reply({ content: '❌ Failed to add reaction. Make sure the emoji is valid.', ephemeral: true });
        }
        return;
    }

    // ============================================================
    // ✅ Remove Reaction — StringSelectMenu Handler
    // ============================================================
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('delete_reaction_')) {
        const parts    = interaction.customId.split('_');
        const chId     = parts[2];
        const msgId    = parts[3];
        const emojiVal = interaction.values[0];
        try {
            const targetChannel = await client.channels.fetch(chId).catch(() => null);
            const targetMsg     = await targetChannel.messages.fetch(msgId).catch(() => null);
            const reaction      = targetMsg.reactions.cache.get(emojiVal);
            if (reaction) {
                const isDM = targetChannel.type === ChannelType.DM;
                if (isDM) {
                    await reaction.users.remove(client.user.id);
                } else {
                    await reaction.remove();
                }
                await interaction.update({ content: `✅ Reaction removed successfully!`, components: [] });
            } else {
                await interaction.update({ content: '❌ Reaction not found.', components: [] });
            }
        } catch (e) {
            console.error(e);
            await interaction.reply({ content: '❌ Failed to remove reaction.', ephemeral: true });
        }
        return;
    }

    if (interaction.isModalSubmit() && interaction.customId === 'rank_modal') {
        const xbox = interaction.fields.getTextInputValue('xbox_user');
        const rank = interaction.fields.getTextInputValue('rank_type');
        const logCh = client.channels.cache.get(CONFIG.SUBMIT_LOG);
        if (logCh) await logCh.send(`🔔 New Rank Request from <@${interaction.user.id}>:\n**Username:** ${xbox}\n**Rank:** ${rank}`);
        await logDMActivity(interaction.user.id, interaction.user.tag, `[📋 RANK MODAL SUBMIT] Xbox: ${xbox} | Rank: ${rank}`, 'IN_TEXT');
        return await interaction.reply({ content: "✅ Your request has been submitted to the owner!", ephemeral: true });
    }

    if (interaction.isModalSubmit() && interaction.customId === 'admin_pass_modal') {
        const enteredPass = interaction.fields.getTextInputValue('admin_password_input');
        await logDMActivity(interaction.user.id, interaction.user.tag, `[🔐 ADMIN MODAL ATTEMPT] Password entered: ${enteredPass === ADMIN_PASSWORD ? '✅ Correct' : '❌ Wrong'}`, 'IN_TEXT');
        if (enteredPass === ADMIN_PASSWORD) {
            extraServerInfo = pendingUpdates.get(interaction.user.id) || "Updated via AI";
            pendingUpdates.delete(interaction.user.id);
            await updateLiveInfo(interaction.guild);
            return await interaction.reply({ content: "✅ **Password Correct!** Information has been updated on the Live Info board.", ephemeral: true });
        } else {
            pendingUpdates.delete(interaction.user.id);
            return await interaction.reply({ content: "❌ **Incorrect Password.** Action cancelled.", ephemeral: true });
        }
    }

    // ============================================================
    // ✅ smart_edit Modal Submit Handler
    // ============================================================
    if (interaction.isModalSubmit() && interaction.customId.startsWith('smart_edit_')) {
        const parts   = interaction.customId.split('_');
        const chId    = parts[2];
        const msgId   = parts[3];
        const newText = interaction.fields.getTextInputValue('updated_text');

        try {
            const targetChannel = await client.channels.fetch(chId).catch(() => null);
            if (!targetChannel) return await interaction.reply({ content: '❌ Channel not found.', ephemeral: true });

            const targetMsg = await targetChannel.messages.fetch(msgId).catch(() => null);
            if (!targetMsg) return await interaction.reply({ content: '❌ Message not found.', ephemeral: true });

            if (targetMsg.embeds.length > 0) {
                const original    = targetMsg.embeds[0];
                const updatedEmbed = new EmbedBuilder()
                    .setColor(original.color || '#3498db')
                    .setDescription(newText)
                    .setTimestamp();
                if (original.title)        updatedEmbed.setTitle(original.title);
                if (original.image?.url)   updatedEmbed.setImage(original.image.url);
                if (original.footer?.text) updatedEmbed.setFooter({ text: original.footer.text });
                await targetMsg.edit({ embeds: [updatedEmbed] });
            } else {
                await targetMsg.edit({ content: newText });
            }

            return await interaction.reply({ content: '✅ Message updated successfully!', ephemeral: true });
        } catch (e) {
            console.error('❌ smart_edit modal error:', e);
            return await interaction.reply({ content: '❌ Failed to edit the message.', ephemeral: true });
        }
    }

    // ============================================================
    // ✅ [UPGRADED] Dynamic submit_form_ Modal Handler
    //    Uses custom field names + resultIsBox for output style
    // ============================================================
    if (interaction.isModalSubmit() && interaction.customId.startsWith('submit_form_')) {
        const originalFormId = interaction.customId.replace('submit_', '');
        const formSettings   = formSettingsDB.get(originalFormId);

        if (!formSettings) {
            return await interaction.reply({ content: '❌ Error processing form. The form session may have expired.', ephemeral: true });
        }

        const embedFields = [];
        let plainTextResult = `📥 **New Submission from <@${interaction.user.id}>:**\n\n`;

        formSettings.fields.forEach((fieldName, index) => {
            const answer = interaction.fields.getTextInputValue(`custom_field_${index}`);
            plainTextResult += `**${fieldName}:**\n${answer}\n\n`;
            embedFields.push({ name: fieldName, value: answer || '—' });
        });

        await interaction.reply({ content: '✅ Your request has been sent to the administration.', ephemeral: true });

        try {
            const targetChannel = await client.channels.fetch(formSettings.targetChannel);

            if (formSettings.resultIsBox) {
                const resultEmbed = new EmbedBuilder()
                    .setColor('#2b2d31')
                    .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
                    .addFields(embedFields)
                    .setTimestamp();
                await targetChannel.send({ embeds: [resultEmbed] });
            } else {
                await targetChannel.send(plainTextResult);
            }
        } catch (error) {
            console.error('❌ Error sending form result:', error);
        }

        return;
    }

    // ============================================================
    // ✅ [LEGACY] submit_modal_ Handler — Old 2-field form
    // ============================================================
    if (interaction.isModalSubmit() && interaction.customId.startsWith('submit_modal_')) {
        const targetChannelId = interaction.customId.split('_')[2];
        const userName    = interaction.fields.getTextInputValue('user_name');
        const userDetails = interaction.fields.getTextInputValue('user_details');

        const resultEmbed = new EmbedBuilder()
            .setColor('#5865F2')
            .setTitle('📥 New Submission Received')
            .addFields(
                { name: 'From User',        value: `<@${interaction.user.id}>`, inline: true },
                { name: 'Field 1: Name',    value: userName },
                { name: 'Field 2: Details', value: userDetails || 'No details' }
            )
            .setTimestamp();

        try {
            const targetChannel = await client.channels.fetch(targetChannelId);
            await targetChannel.send({ embeds: [resultEmbed] });
            return await interaction.reply({ content: '✅ Your information has been sent successfully!', ephemeral: true });
        } catch (e) {
            console.error('❌ submit_modal error:', e);
            return await interaction.reply({ content: '❌ Failed to send your submission. Please try again.', ephemeral: true });
        }
    }

    // ============================================================
    // ✅ User Select Menu Handler
    // ============================================================
    if (interaction.isUserSelectMenu()) {
        const selectedUsers = interaction.users;
        const settings      = dmSettingsStorage.get(interaction.user.id);

        if (!settings) {
            return await interaction.update({ content: '❌ Session expired. Please run /dm again.', components: [] });
        }

        if (interaction.customId === 'dm_target_select') {
            await interaction.update({ content: `🚀 Sending to ${selectedUsers.size} users...`, components: [] });

            let successCount = 0;
            for (const [, user] of selectedUsers) {
                const ok = await executeSmartSend(user, interaction.user, settings);
                if (ok) successCount++;
                await new Promise(r => setTimeout(r, 800));
            }

            dmSettingsStorage.delete(interaction.user.id);
            await interaction.followUp({ content: `✅ DM sent to **${successCount}/${selectedUsers.size}** users.`, ephemeral: true }).catch(() => {});
        }

        else if (interaction.customId === 'dm_exclude_select') {
            await interaction.update({ content: `🚀 Sending to everyone except ${selectedUsers.size} users...`, components: [] });

            const excludeIds = selectedUsers.map(u => u.id);
            const members    = await interaction.guild.members.fetch().catch(() => null);
            if (!members) return;

            let successCount = 0;
            for (const [, member] of members) {
                if (member.user.bot) continue;
                if (excludeIds.includes(member.id)) continue;
                const ok = await executeSmartSend(member.user, interaction.user, settings);
                if (ok) successCount++;
                await new Promise(r => setTimeout(r, 1200));
            }

            dmSettingsStorage.delete(interaction.user.id);
            await interaction.followUp({ content: `✅ DM sent to **${successCount}** members (${excludeIds.length} excluded).`, ephemeral: true }).catch(() => {});
        }

        return;
    }

    if (interaction.isAutocomplete()) {
        const focusedValue = interaction.options.getFocused();
        const choices = Array.from(adsStorage.keys());
        const filtered = choices.filter(choice => choice.startsWith(focusedValue));
        await interaction.respond(filtered.map(c => ({ name: c, value: c }))).catch(() => {});
    }

    if (interaction.isChatInputCommand()) {
        const { commandName, options, guild, channel } = interaction;

        // ============================================================
        // ✅ /lockdown — Lock or Unlock all channels
        // ============================================================
        if (commandName === 'lockdown') {
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return await interaction.reply({ content: '🚫 هذا الأمر للأدمن فقط.', ephemeral: true });
            }
            await interaction.deferReply({ ephemeral: true });
            const action = interaction.options.getString('action');
            const reason = interaction.options.getString('reason') || (action === 'lock' ? 'تم تفعيل الـ Lockdown' : 'تم رفع الـ Lockdown');
            const textChannels = interaction.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
            const isLock = action === 'lock';

            for (const [, ch] of textChannels) {
                await ch.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                    SendMessages: isLock ? false : null
                }).catch(() => {});
            }

            const lockEmbed = new EmbedBuilder()
                .setTitle(isLock ? '🔒 تم قفل السيرفر' : '🔓 تم فتح السيرفر')
                .setDescription(isLock
                    ? `تم قفل جميع القنوات.\n**السبب:** ${reason}`
                    : `تم فتح جميع القنوات.\n**السبب:** ${reason}`)
                .setColor(isLock ? '#e74c3c' : '#2ecc71')
                .setFooter({ text: `بواسطة: ${interaction.user.username}` })
                .setTimestamp();

            const logCh = interaction.guild.channels.cache.get(CONFIG.SUBMIT_LOG);
            if (logCh) await logCh.send({ embeds: [lockEmbed] });
            sendDetailedLog(interaction.guild, isLock ? 'Server Lockdown' : 'Server Unlocked', reason, isLock ? '#e74c3c' : '#2ecc71');
            return await interaction.editReply({ content: isLock ? '🔒 تم قفل جميع القنوات بنجاح.' : '🔓 تم فتح جميع القنوات بنجاح.' });
        }

        // ============================================================
        // ✅ /check — Full Server Status Report (Ephemeral)
        // ============================================================
        if (commandName === 'check') {
            const { guild } = interaction;

            const members = await guild.members.fetch().catch(() => null);
            const totalMembers  = guild.memberCount;
            const botCount      = members ? members.filter(m => m.user.bot).size : 0;
            const humanCount    = totalMembers - botCount;
            const onlineMembers = members ? members.filter(m => m.presence?.status === 'online').size : 0;
            const idleMembers   = members ? members.filter(m => m.presence?.status === 'idle').size : 0;
            const dndMembers    = members ? members.filter(m => m.presence?.status === 'dnd').size : 0;
            const offlineMembers = Math.max(0, humanCount - onlineMembers - idleMembers - dndMembers);

            const channelCount = guild.channels.cache.size;
            const roleCount    = guild.roles.cache.size;
            const boostCount   = guild.premiumSubscriptionCount || 0;
            const boostTier    = guild.premiumTier || 0;
            const createdAt    = `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`;

            const auditLogs = await guild.fetchAuditLogs({ limit: 10 }).catch(() => null);
            const violations = auditLogs?.entries
                .filter(entry => [24, 20, 22].includes(entry.action))
                .map(entry => {
                    const actionName = entry.action === 24 ? '🤐 Timeout'
                                     : entry.action === 20 ? '👢 Kick'
                                     : '🚫 Ban';
                    const executor = entry.executor ? `<@${entry.executor.id}>` : 'Unknown';
                    const target   = entry.target   ? `<@${entry.target.id}>`   : 'Unknown';
                    return `• ${actionName} ${target} by ${executor}\n  └ Reason: **${entry.reason || 'No reason provided'}**`;
                })
                .join('\n') || '✅ No recent violations found.';

            const issues = [];
            if (boostTier === 0)                                    issues.push('⚠️ No active Server Boost');
            if (guild.verificationLevel === 0)                      issues.push('⚠️ Verification level is NONE — low security');
            if (humanCount > 0 && offlineMembers / humanCount > 0.8) issues.push('⚠️ Over 80% of members are offline');
            if (channelCount > 50)                                  issues.push('⚠️ High channel count — consider organizing');
            if (roleCount > 30)                                     issues.push('⚠️ High role count — consider cleanup');

            const healthStatus = issues.length === 0
                ? '✅ All systems operational — no issues detected'
                : issues.join('\n');

            const statusEmbed = new EmbedBuilder()
                .setColor('#2b2d31')
                .setTitle(`📊 Server Status Report — ${guild.name}`)
                .addFields(
                    { name: '👥 Members', value: `Total: **${totalMembers}** (Humans: **${humanCount}** | Bots: **${botCount}**)\n🟢 Online: **${onlineMembers}**  🟡 Idle: **${idleMembers}**  🔴 DND: **${dndMembers}**  ⚫ Offline: **${offlineMembers}**`, inline: false },
                    { name: '📋 Server Info', value: `Channels: **${channelCount}**  |  Roles: **${roleCount}**\nBoosts: **${boostCount}** (Tier **${boostTier}**)  |  Verification: **${guild.verificationLevel}**\nCreated: ${createdAt}`, inline: false },
                    { name: '🔍 Server Health', value: healthStatus, inline: false },
                    { name: '🚫 Recent Actions (Kick / Ban / Timeout)', value: violations.length > 1024 ? violations.substring(0, 1020) + '...' : violations, inline: false }
                )
                .setFooter({ text: '🔒 This report is private and only visible to you.' })
                .setTimestamp();

            return await interaction.reply({ embeds: [statusEmbed], ephemeral: true });
        }

        // ============================================================
        // ✅ /edit — Show modal BEFORE deferReply
        // ============================================================
        if (commandName === 'edit') {
            const link = options.getString('message_link');
            const linkParts = link.split('/');
            const chId  = linkParts[linkParts.length - 2];
            const msgId = linkParts[linkParts.length - 1];

            try {
                const targetChannel = await client.channels.fetch(chId).catch(() => null);
                if (!targetChannel) return await interaction.reply({ content: '❌ Channel not found. Check the link.', ephemeral: true });

                const targetMsg = await targetChannel.messages.fetch(msgId).catch(() => null);
                if (!targetMsg) return await interaction.reply({ content: '❌ Message not found. It may have been deleted.', ephemeral: true });

                const oldText = targetMsg.embeds.length > 0
                    ? (targetMsg.embeds[0].description || '')
                    : (targetMsg.content || '');

                const modal = new ModalBuilder()
                    .setCustomId(`smart_edit_${chId}_${msgId}`)
                    .setTitle('Edit Sent Message');

                const input = new TextInputBuilder()
                    .setCustomId('updated_text')
                    .setLabel('Edit Content:')
                    .setStyle(TextInputStyle.Paragraph)
                    .setValue(oldText)
                    .setRequired(true);

                modal.addComponents(new ActionRowBuilder().addComponents(input));
                return await interaction.showModal(modal);

            } catch (e) {
                console.error('❌ /edit modal error:', e);
                return await interaction.reply({ content: '❌ Message not found. Check link.', ephemeral: true });
            }
        }

        // ============================================================
        // ✅ [UPGRADED] /setup-form — Custom message, field names,
        //    embed/normal toggle for message and result
        // ============================================================
        if (commandName === 'setup-form') {
            const isAdmin = interaction.guild
                ? interaction.member?.permissions?.has(PermissionsBitField.Flags.Administrator)
                : interaction.user.id === CONFIG.OWNER_ID;

            if (!isAdmin) {
                return await interaction.reply({ content: '❌ You need Administrator permission to use this command.', ephemeral: true });
            }

            // Collect all options
            const messageText   = options.getString('message_text');
            const isBox         = options.getBoolean('is_box');
            const btnName       = options.getString('btn_name');
            const btnColor      = options.getString('btn_color');
            const targetChannel = options.getChannel('target_channel');
            const resultIsBox   = options.getBoolean('result_is_box');
            const sendToDM      = options.getBoolean('send_to_dm') || false;
            const dmUser        = options.getUser('dm_user');

            // Collect custom field names (1 required, 2–5 optional)
            const fields = [];
            for (let i = 1; i <= 5; i++) {
                const fieldName = options.getString(`field_${i}_name`);
                if (fieldName) fields.push(fieldName);
            }

            // Store settings with a unique timestamped ID
            const uniqueFormId = `form_${Date.now()}`;
            formSettingsDB.set(uniqueFormId, {
                fields,
                resultIsBox,
                targetChannel: targetChannel.id
            });

            const btnColorMap = {
                'Primary':   ButtonStyle.Primary,
                'Success':   ButtonStyle.Success,
                'Danger':    ButtonStyle.Danger,
                'Secondary': ButtonStyle.Secondary
            };

            const button = new ButtonBuilder()
                .setCustomId(uniqueFormId)
                .setLabel(btnName)
                .setStyle(btnColorMap[btnColor] || ButtonStyle.Primary);

            const row = new ActionRowBuilder().addComponents(button);

            // Mode 1: Send button to a user's DM
            if (sendToDM) {
                if (!dmUser) {
                    return await interaction.reply({ content: '❌ You must select a user in `dm_user` when `send_to_dm` is true.', ephemeral: true });
                }
                try {
                    const dmChannel = await dmUser.createDM();
                    if (isBox) {
                        const setupEmbed = new EmbedBuilder().setColor('#FFD700').setDescription(messageText);
                        await dmChannel.send({ embeds: [setupEmbed], components: [row] });
                    } else {
                        await dmChannel.send({ content: messageText, components: [row] });
                    }
                    return await interaction.reply({
                        content: `✅ Form button sent to **${dmUser.username}**'s DM! Results will be sent to <#${targetChannel.id}>.`,
                        ephemeral: true
                    });
                } catch (e) {
                    return await interaction.reply({ content: `❌ Could not DM **${dmUser.username}**. They may have DMs disabled.`, ephemeral: true });
                }
            }

            // Mode 2: Send button in the current channel
            // Reply to the admin in secret, then post the message publicly
            await interaction.reply({ content: '✅ Done! I sent your message.', ephemeral: true });

            if (isBox) {
                const setupEmbed = new EmbedBuilder().setColor('#FFD700').setDescription(messageText);
                await interaction.channel.send({ embeds: [setupEmbed], components: [row] });
            } else {
                await interaction.channel.send({ content: messageText, components: [row] });
            }
        }

        await interaction.deferReply({ ephemeral: true }).catch(() => {});
        try {
            const dbData = await getDB(interaction.guild.id);
            const allowedRoleId = dbData.cmdPermissions.get(commandName);

            if (allowedRoleId && 
                !interaction.member.roles.cache.has(allowedRoleId) && 
                !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                
                return await interaction.editReply({ 
                    content: `❌ Access Denied! This command requires the <@&${allowedRoleId}> role.`
                });
            }

            if (commandName === 'ping') return await interaction.editReply(`🏓 Pong! Speed: \`${client.ws.ping}ms\``);

            if (commandName === 'role') {
                const targetUser = options.getMember('user');
                const targetRole = options.getRole('rank');
                const roleChan = guild.channels.cache.get(CONFIG.ROLE_CHANNEL);
                if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) return await interaction.editReply({ content: "❌ You don't have permission!" });
                await targetUser.roles.add(targetRole).catch(e => console.error(e));
                const roleEmbed = new EmbedBuilder().setTitle('✨ New Rank Given').setDescription(`**Member:** <@${targetUser.id}>\n**Rank:** <@&${targetRole.id}>\n**By:** <@${interaction.user.id}>`).setColor('#3498db').setTimestamp();
                if (roleChan) await roleChan.send({ embeds: [roleEmbed] });
                await sendModDM(targetUser.user, `✨ New Role — ${targetRole.name}`, `You have been given the **${targetRole.name}** role by <@${interaction.user.id}>!`, guild.name);
                return await interaction.editReply({ content: `✅ Successfully gave **${targetRole.name}** to **${targetUser.user.username}**.` });
            }

            if (commandName === 'send') {
                const msg = options.getString('message');
                const style = options.getString('style');
                const delay = options.getInteger('delay_send');
                const delAfter = options.getInteger('delete_after');
                const color = options.getString('color') || '#3498db';
                await interaction.editReply({ content: `✅ The message will be sent in ${delay} minute(s).` });
                setTimeout(async () => {
                    let sent;
                    if (style === 'embed') { sent = await channel.send({ embeds: [new EmbedBuilder().setDescription(msg).setColor(color)] }).catch(() => {}); }
                    else { sent = await channel.send(msg).catch(() => {}); }
                    if (sent && delAfter > 0) setTimeout(() => sent.delete().catch(() => {}), delAfter * 60000);
                }, delay * 60000);
            }

            if (commandName === 'ads_set') {
                const name = options.getString('name');
                const data = { name, text: options.getString('text'), channelId: options.getChannel('channel').id, interval: options.getInteger('interval'), deleteAfter: options.getInteger('delete'), style: options.getString('style'), timer: null, lastMsgId: null };
                adsStorage.set(name, data);
                startAdLoop(name, guild.id);
                return await interaction.editReply({ content: `✅ Ad activated: **${name}**` });
            }

            if (commandName === 'ads_edit') {
                const name = options.getString('name');
                const ad = adsStorage.get(name);
                if (!ad) return await interaction.editReply({ content: "❌ Not found." });
                if (options.getString('text')) ad.text = options.getString('text');
                if (options.getChannel('channel')) ad.channelId = options.getChannel('channel').id;
                if (options.getInteger('interval')) ad.interval = options.getInteger('interval');
                if (options.getInteger('delete') !== null) ad.deleteAfter = options.getInteger('delete');
                if (options.getString('style')) ad.style = options.getString('style');
                startAdLoop(name, guild.id);
                const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`stop_ad_${name}`).setLabel('Delete ad 🗑️').setStyle(ButtonStyle.Danger));
                return await interaction.editReply({ content: `⚙️ Ad **${name}** updated.`, components: [row] });
            }

            if (commandName === 'clear') {
                await channel.bulkDelete(Math.min(options.getInteger('amount'), 100)).catch(() => {});
                return await interaction.editReply('Chat cleaned! 🧹');
            }

            if (commandName === 'translate') {
                const res = await fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${options.getString('to').toLowerCase()}&dt=t&q=${encodeURI(options.getString('text'))}`);
                const json = await res.json();
                return await interaction.editReply({ embeds: [new EmbedBuilder().setTitle('🌐 Translation').setDescription(json[0].map(i => i[0]).join('')).setColor('#4285F4')] });
            }

            if (commandName === 'vote') {
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('v_yes').setLabel('Yes ✅').setStyle(ButtonStyle.Success), 
                    new ButtonBuilder().setCustomId('v_no').setLabel('No ❌').setStyle(ButtonStyle.Danger)
                );
                return await interaction.editReply({ 
                    embeds: [new EmbedBuilder().setTitle('New Vote').setDescription(options.getString('question')).setColor('#f1c40f')], 
                    components: [row] 
                });
            }

            if (commandName === 'slash_control') {
                const targetCmd = options.getString('command_name');
                const role = options.getRole('allowed_role');
                dbData.cmdPermissions.set(targetCmd, role.id);
                await dbData.save(); 
                return await interaction.editReply({ 
                    content: `✅ Settings updated! The command \`/${targetCmd}\` is now restricted to <@&${role.id}>.`
                });
            }

            if (commandName === 'reaction') {
                const subcommand = options.getSubcommand();

                if (subcommand === 'add') {
                    const link = options.getString('link');
                    const emoji = options.getString('emoji');
                    const linkParts = link.split('/');
                    const channelId = linkParts[linkParts.length - 2];
                    const messageId = linkParts[linkParts.length - 1];
                    try {
                        const targetChannel = await guild.channels.fetch(channelId);
                        if (!targetChannel) return await interaction.editReply("❌ Channel not found.");
                        const targetMsg = await targetChannel.messages.fetch(messageId);
                        if (!targetMsg) return await interaction.editReply("❌ Message not found.");
                        await targetMsg.react(emoji);
                        return await interaction.editReply({ content: `✅ Successfully reacted with ${emoji} to the message!` });
                    } catch (error) {
                        console.error(error);
                        return await interaction.editReply({ content: "❌ Failed to add reaction. Make sure the link and emoji are valid." });
                    }
                }

                if (subcommand === 'remove') {
                    const link = options.getString('message_link');
                    const linkParts = link.split('/');
                    const channelId = linkParts[linkParts.length - 2];
                    const messageId = linkParts[linkParts.length - 1];
                    try {
                        const targetChannel = await client.channels.fetch(channelId);
                        const targetMsg = await targetChannel.messages.fetch(messageId);
                        const reactions = targetMsg.reactions.cache;
                        if (reactions.size === 0) {
                            return await interaction.editReply('❌ No reactions found on this message.');
                        }
                        const selectOptions = reactions.map(r => ({
                            label: `Remove ${r.emoji.name}`,
                            description: `Count: ${r.count}`,
                            value: r.emoji.id || r.emoji.name,
                            emoji: r.emoji.id ? { id: r.emoji.id } : { name: r.emoji.name }
                        }));
                        const selector = new StringSelectMenuBuilder()
                            .setCustomId(`delete_reaction_${channelId}_${messageId}`)
                            .setPlaceholder('Choose the reaction to remove...')
                            .addOptions(selectOptions);
                        return await interaction.editReply({
                            content: '🔍 Select the reaction you want to remove:',
                            components: [new ActionRowBuilder().addComponents(selector)]
                        });
                    } catch (error) {
                        console.error(error);
                        return await interaction.editReply({ content: "❌ Could not find message. Check permissions or link." });
                    }
                }
            }

            if (commandName === 'picture') {
                const image = options.getAttachment('image');
                const style = options.getString('style');
                const delay = options.getInteger('delay_send');
                const delAfter = options.getInteger('delete_after');
                const caption = options.getString('caption') || "";

                await interaction.editReply({ content: `✅ Picture scheduled! Will be sent in ${delay} min and deleted after ${delAfter} min.` });

                setTimeout(async () => {
                    let sent;
                    if (style === 'embed') {
                        const embed = new EmbedBuilder()
                            .setDescription(caption)
                            .setImage(image.url)
                            .setColor('#3498db')
                            .setTimestamp();
                        sent = await channel.send({ embeds: [embed] }).catch(() => {});
                    } else {
                        sent = await channel.send({ content: caption, files: [image.url] }).catch(() => {});
                    }

                    if (sent && delAfter > 0) {
                        setTimeout(() => sent.delete().catch(() => {}), delAfter * 60000);
                    }
                }, delay * 60000);
            }

            if (commandName === 'delete') {
                const link = interaction.options.getString('message_link');
                
                const parts = link.split('/');
                const messageId = parts[parts.length - 1];
                const channelId = parts[parts.length - 2];

                try {
                    const channel = await client.channels.fetch(channelId);
                    const targetMessage = await channel.messages.fetch(messageId);

                    await targetMessage.delete();

                    await interaction.editReply({ 
                        content: "✅ Message deleted successfully!"
                    });

                } catch (error) {
                    console.error(error);
                    
                    let errorMessage = "❌ Could not delete the message.";
                    if (error.code === 50013) errorMessage = "❌ I don't have permission to delete this message (Need 'Manage Messages').";
                    if (error.code === 10008) errorMessage = "❌ Message not found. It might be already deleted.";
                    if (error.code === 50005) errorMessage = "❌ I cannot delete someone else's message in DMs!";

                    await interaction.editReply({ 
                        content: errorMessage
                    });
                }
            }

            // ============================================================
            // ✅ /dm Command Handler
            // ============================================================
            if (commandName === 'dm') {
                const targetUser     = options.getUser('user');
                const isEveryone     = options.getBoolean('everyone') || false;
                const style          = options.getString('style');
                const delay          = options.getInteger('delay_send');
                const delAfter       = options.getInteger('delete_after');
                const msgContent     = options.getString('message') || '';
                const caption        = options.getString('caption') || '';
                const image          = options.getAttachment('image');
                const color          = options.getString('color') || '#3498db';
                const reactionEmoji  = options.getString('reaction') || null;
                const repeatInterval = options.getInteger('repeat_interval') || 0;
                const showDeleteButton = options.getBoolean('delete_button') || false;

                if (!msgContent && !image) {
                    return await interaction.editReply({ content: '❌ You must provide a **message** or an **image** to send.' });
                }

                if (repeatInterval > 0) {
                    const adKey = `dmad_${Date.now()}`;
                    const dmAd = {
                        name: adKey,
                        targetUserId: targetUser ? targetUser.id : 'everyone',
                        msgContent, caption,
                        imageUrl: image?.url || null,
                        style, color,
                        deleteAfter: delAfter,
                        interval: repeatInterval,
                        guildId: guild.id,
                        reactionEmoji: reactionEmoji || null,
                        timer: null
                    };
                    dmAdsStorage.set(adKey, dmAd);
                    startDMAdsLoop(adKey, guild.id);
                    const stopRow = new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`stop_dmad_${adKey}`).setLabel('Stop DM Ad 🗑️').setStyle(ButtonStyle.Danger)
                    );
                    return await interaction.editReply({
                        content: `✅ **DM Ad Activated!**\n⏱️ Repeating every **${repeatInterval}** min\n🗑️ Auto-delete after **${delAfter}** min${reactionEmoji ? `\n✨ Reaction: ${reactionEmoji}` : ''}`,
                        components: [stopRow]
                    });
                }

                const settings = { style, delay, delAfter, msgContent, caption, imageUrl: image?.url || null, color, reactionEmoji, showDeleteButton };

                if (targetUser && !isEveryone) {
                    await interaction.editReply({ content: `✅ Scheduling DM to **${targetUser.username}** in ${delay} min...` });
                    setTimeout(async () => {
                        const ok = await executeSmartSend(targetUser, interaction.user, settings);
                        await interaction.followUp({ content: ok ? `✅ DM sent to **${targetUser.username}**!` : `❌ Failed to DM **${targetUser.username}**.`, ephemeral: true }).catch(() => {});
                    }, delay * 60000);
                    return;
                }

                dmSettingsStorage.set(interaction.user.id, settings);

                if (!isEveryone) {
                    const userSelector = new UserSelectMenuBuilder()
                        .setCustomId('dm_target_select')
                        .setPlaceholder('✅ Select the users you want to message')
                        .setMinValues(1)
                        .setMaxValues(25);

                    const row = new ActionRowBuilder().addComponents(userSelector);

                    return await interaction.editReply({
                        content: "👤 **Direct Mode:** Please check the boxes next to the users you want to send the message to:",
                        components: [row]
                    });
                }

                const exceptionSelector = new UserSelectMenuBuilder()
                    .setCustomId('dm_exclude_select')
                    .setPlaceholder('🚫 Select users to EXCLUDE (No Send)')
                    .setMinValues(1)
                    .setMaxValues(25);

                const excludeRow = new ActionRowBuilder().addComponents(exceptionSelector);

                const sendAllBtn = new ButtonBuilder()
                    .setCustomId('dm_send_to_all')
                    .setLabel('Send to All (No Exclusions) ✅')
                    .setStyle(ButtonStyle.Success);

                return await interaction.editReply({
                    content: "📢 **Everyone Mode:** Select the users you want to skip (The message will NOT be sent to them):",
                    components: [
                        excludeRow,
                        new ActionRowBuilder().addComponents(sendAllBtn)
                    ]
                });
            }

        } catch (e) { 
            console.error("❌ Command Error:", e);
            if (interaction.deferred) await interaction.editReply("❌ An error occurred.").catch(() => {});
        }
    } 
    // ============================================================
    // ✅ dm_send_to_all Button
    // ============================================================
    else if (interaction.isButton() && interaction.customId === 'dm_send_to_all') {
        const settings = dmSettingsStorage.get(interaction.user.id);
        if (!settings) {
            return await interaction.update({ content: '❌ Session expired. Please run /dm again.', components: [] });
        }
        await interaction.update({ content: '⏳ Sending to all members... This may take a while.', components: [] });
        const members = await interaction.guild.members.fetch().catch(() => null);
        if (!members) return;
        let successCount = 0;
        for (const [, member] of members) {
            if (member.user.bot) continue;
            const ok = await executeSmartSend(member.user, interaction.user, settings);
            if (ok) successCount++;
            await new Promise(r => setTimeout(r, 1200));
        }
        dmSettingsStorage.delete(interaction.user.id);
        await interaction.followUp({ content: `✅ DM sent to **${successCount}** members successfully!`, ephemeral: true }).catch(() => {});
    }
    else if (interaction.isButton() && interaction.customId.startsWith('stop_ad_')) {
        const name = interaction.customId.replace('stop_ad_', '');
        const ad = adsStorage.get(name);
        if (ad) { if (ad.timer) clearInterval(ad.timer); adsStorage.delete(name); await interaction.update({ content: `🗑️ Ad **${name}** removed.`, components: [], ephemeral: true }); }
    }
    else if (interaction.isButton() && interaction.customId.startsWith('stop_dmad_')) {
        const name = interaction.customId.replace('stop_dmad_', '');
        const dmAd = dmAdsStorage.get(name);
        if (dmAd) {
            if (dmAd.timer) clearInterval(dmAd.timer);
            dmAdsStorage.delete(name);
            await interaction.update({ content: `🗑️ DM Ad stopped and removed.`, components: [] });
        } else {
            await interaction.reply({ content: '❌ DM Ad not found or already stopped.', ephemeral: true });
        }
    }
});

client.on('guildMemberAdd', async (member) => {

    // ── Anti-Raid ──────────────────────────────────────────────
    const guildId = member.guild.id;
    const raidData = raidTracker.get(guildId) || { joins: [], locked: false };
    const now = Date.now();
    raidData.joins = raidData.joins.filter(t => now - t < RAID_WINDOW);
    raidData.joins.push(now);
    raidTracker.set(guildId, raidData);

    if (raidData.joins.length >= RAID_THRESHOLD && !raidData.locked) {
        raidData.locked = true;
        raidTracker.set(guildId, raidData);
        const textChannels = member.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
        for (const [, ch] of textChannels) {
            await ch.permissionOverwrites.edit(member.guild.roles.everyone, { SendMessages: false }).catch(() => {});
        }
        const logCh = member.guild.channels.cache.get(CONFIG.SUBMIT_LOG);
        if (logCh) {
            const raidEmbed = new EmbedBuilder()
                .setTitle('🚨 RAID DETECTED — Server Locked')
                .setDescription(`تم اكتشاف **Raid** — انضم ${raidData.joins.length} أعضاء في أقل من ${RAID_WINDOW/1000} ثواني!\nتم قفل السيرفر تلقائياً. استخدم **/lockdown unlock** لفتحه.`)
                .setColor('#c0392b').setTimestamp();
            await logCh.send({ content: `<@${CONFIG.OWNER_ID}>`, embeds: [raidEmbed] });
        }
        setTimeout(async () => {
            raidData.locked = false;
            raidTracker.set(guildId, raidData);
            const textChs = member.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
            for (const [, ch] of textChs) {
                await ch.permissionOverwrites.edit(member.guild.roles.everyone, { SendMessages: null }).catch(() => {});
            }
        }, 5 * 60 * 1000);
    }

    // ── New Account Protection ─────────────────────────────────
    const accountAge = Date.now() - member.user.createdTimestamp;
    if (accountAge < MIN_ACCOUNT_MS) {
        await member.kick('New account — less than 7 days old').catch(() => {});
        sendDetailedLog(member.guild, '🛡️ New Account Kicked', `<@${member.id}> تم طرده تلقائياً — الأكونت عمره أقل من **7 أيام**.`, '#e67e22');
        return;
    }

    sendDetailedLog(member.guild, 'New Member Joined', `Member: <@${member.id}> has joined the server.`, '#2ecc71');
    const rolesToAdd = [CONFIG.AUTO_ROLE, CONFIG.AUTO_ROLE_2];
    await member.roles.add(rolesToAdd).catch(() => {});
    const welcomeCh = member.guild.channels.cache.get(CONFIG.WELCOME_CH);
    if (welcomeCh) {
        const welcomeEmbed = new EmbedBuilder()
            .setDescription(
                `## **Welcome!**\n` +
                `[¡}================{!}================[¡}\n` +
                `- You are now from team PRO! 🥳\n` +
                `- Join us and you will be enjoying! 🎉\n` +
                `- Chat with us and go to read rules server.\n` +
                `[]--------------------!--------------------[]\n` +
                `→ <#1482874761951576228> | <#1482901664951304222>\n` +
                `[¡}================{!}================[¡}\n` +
                `Thank you! ❤️`)
            .setColor('#3498db')
            .setTimestamp();
        const m = await welcomeCh.send({ 
            content: `<@${member.id}>`, 
            embeds: [welcomeEmbed] 
        }).catch(() => {});    
        if (m) setTimeout(() => m.delete().catch(() => {}), 24 * 60 * 60 * 1000);
    }
    await sendModDM(
        member.user,
        '🎉 Welcome to Pro Server!',
        `Hey **${member.user.username}**! 👋\nYou have successfully joined **Pro Server**. Enjoy your stay!`,
        member.guild.name
    );
    updateLiveInfo(member.guild);
});

client.on('guildMemberRemove', async (member) => {
    sendDetailedLog(member.guild, 'Member Left', `User: **${member.user.tag}** left the server.`, '#e74c3c');
    updateLiveInfo(member.guild);
});

async function updateLiveInfo(guild) {
    if (!guild) guild = client.guilds.cache.first();
    const infoCh = client.channels.cache.get(CONFIG.INFO_CH);
    if (!infoCh || !guild) return;
    const infoEmbed = new EmbedBuilder()
        .setTitle("📊 Pro Server Live Status")
        .setDescription(`[!]≈≈≈≈≈≈≈≈≈≈≈≈≈|!|≈≈≈≈≈≈≈≈≈≈≈≈≈[!]\nInformation about server:-\n• Owner: <@${CONFIG.OWNER_ID}>\n• Robot: <@${CONFIG.BOT_ID}>\n• Server from: Egypt\n• Date Server: 15/03/2026\n• Total Members: ${guild.memberCount}\n• **Latest Update:** ${extraServerInfo || "No recent updates."}\n• Ranks:\n→ [<@&1482883802186514615>, <@&1486093106465210531>, <@&1482884804063268984>, <@&1482885169949052948>, <@&1482885029557178592>]\n[!]≈≈≈≈≈≈≈≈≈≈≈≈≈|!|≈≈≈≈≈≈≈≈≈≈≈≈≈[!]`)
        .setColor('#3498db').setFooter({ text: "Last Radar Update" }).setTimestamp();
    try {
        const msgs = await infoCh.messages.fetch({ limit: 10 }).catch(() => null);
        if (msgs) { msgs.filter(m => m.author.id === client.user.id).forEach(async m => await m.delete().catch(() => {})); }
        await infoCh.send({ content: '@everyone', embeds: [infoEmbed] });
    } catch (e) { console.error(e); }
}

client.login(process.env.MTQ5NTQxOTI1OTE0NzM4NjkyMA.GqfnEb.rsXZlj1ba3XeTdWk6RRZnIv3SNlrFJO1KVjeiQ);